import { Fragment, useState } from 'react'
import './App.scss'
import Header from './components/Header/Header'
import Product from './components/Product/Product'


const  App=() =>{

  return (
    <Fragment>
      <Header/>
    <Product/>
    </Fragment>
  )
}

export default App
