import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Header.scss';

const Header = () => {
    const [hover, setHover] = useState(false);
    const [showSecondImage, setShowSecondImage] = useState(true);
  
    const handleHover = () => {
      setHover(!hover);
      setShowSecondImage(!showSecondImage);
    };

    return (
        <>
            <div className="header">
                <div className="container">
                    <div className="header__wrapper">
                        <div className="header__flex">
                            <Link to={"/#"}>
                                <img src="logo.png" alt="" className="Logo" />
                            </Link>
                            <nav>
                                <ul className='header__nav'>
                                    <li className='header__text'><Link to={"/a"}>Главная</Link></li>
                                    <li className='header__text'><Link to={"/"}>О Компании</Link></li>
                                    <li className='header__text'><Link to={"/"}>Продукты</Link></li>
                                    <li className='header__text'><Link to={"/"}>Рецепты</Link></li>
                                    <li className='header__text'><Link to={"/"}>Наши Партнеры</Link></li>
                                    <li className='Ru'><Link to={"/"}>Ru</Link></li>
                                </ul>
                            </nav>
                        </div>
                        <button
                            className='header__btn'
                            onMouseEnter={handleHover}
                            onMouseLeave={handleHover}
                            style={{ backgroundColor: hover ? 'white' : 'rgb(252, 73, 73)' }}
                        >
                            {hover && <img src="call_red.png" alt="" />}

                            {showSecondImage ? <img src="call.svg" alt="" /> : null}

                            <a href="tel:+998881020">+998(88)179-10-20</a>
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Header;
